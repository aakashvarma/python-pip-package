from setuptools import setup

setup(name='package',
      version='0.1',
      description='A python testing package',
      url='https://github.com/aakashvarma/python-pip-package',
      author='Suspended Hysteria',
      author_email='suspendedhysteria@gmail.com',
      license='MIT',
      packages=['package'],
      zip_safe=False)